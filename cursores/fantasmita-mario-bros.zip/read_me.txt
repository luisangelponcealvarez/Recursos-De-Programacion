Created By TheRocaN64
Downloaded @ http://www.cursors-4u.com/

=================
Author's Note
=================

XP i got cursor feva!  I know it's a bit soon to be posting again but I just love making cursors for every flavor of person, so here are a boo and thwomp cursor set.  The boo set is small and the thwomp set has some good detail for it's set Imo.  I'll try to slow down, but that may be hard cuz I've been wanting to make these and other sets in mind for a while and job hunting has really bumming me out.  And like the pokemon sets, i wouldn't mind requests for specific mario characters to be cursorized.  All rights belong to nintendo and all it's affiliates.  I do not own any of the rights.